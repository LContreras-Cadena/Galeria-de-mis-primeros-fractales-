A continuación les presentare algunos tipos de fractales que trabajamos en clase, cada uno de estos con 4 ejemplos diferentes del trabajado en clase, cada uno de estos fractales fue generado por un codigo a traves de Python, por lo cual para poder generar dichos fractales necesitaremos las siguientes librerias de Python. 


```python
import matplotlib.pyplot as plt                                               #la usamos para generar las imagenes 
from PIL import Image                                                         # la usamos para generar imagenes con pixeles
from ipywidgets import interact, interactive, fixed, interact_manual, widgets #la usamos para poder aplicar widgets en nuestro codigo
from sympy.parsing.sympy_parser import parse_expr
from mpl_toolkits.mplot3d import Axes3D                                       # este es para poder generar graficas e imagenes en 3d
from sympy.plotting import plot3d,plot
import sympy as spp
import numpy as np
```

Luego de mirara que librerias usaremos definiremos la cantidad de pixeles con los que queremos generar la imagen de cada fractal.


```python
imgx=400                           #es la cantidad de pixeles que tendremos en el eje x 
imgy=400                           #es la cantidad de pixeles que tendremos en el eje y
image=Image.new("RGB",(imgx,imgy)) #usamos el sistema RGB para darle un color a cada pixel 
image.putpixel((100,100),(255,255,255))
```

Teniendo clara la cantidad de pixeles que queremos usar en nuestros fractales y el sistema que usaremos para darle color, definiremos ahora los rangos en los cuales queremos generar los fractales.


```python
#Rangos del problema
xa=-2 
xb=2
ya=-2
yb=2
maxit=20  #Maxima cantidad de iteraciones 
h=1e-6
eps=1e-3 #error permitido
```

Ahora teniendo claro lo que usaremos para generar nuestros fractales, en general, comenzaremos a formar los diferentes tipos de fractal que podemos generar con ayuda de Python.

# Conjuntos de Newton

Primero comencemos dando una pequeña definición de que son los conjuntos de Newton, o mejor dicho que son los fractales de Newton. El fractal Newton es un límite establecido en el plano complejo que se caracteriza por el método de Newton aplicada a un fijo polinomio función o trascendental. En otras palabras, con las raices que nos da el aplicar el metodo de Newton las podemos plasmar en un plano de tal torma que dichas raices nos forma un fractal como lo podemos ver a continuación.


```python
#NEWTON ejemplo en clase 
def f(z): 
  return z**3-1

for y in range(imgy):
  zy=y*(yb-ya)/(imgy-1)+ya
  for x in range(imgx):
    zx=x*(xb-xa)/(imgx-1)+xa
    z=complex(zx,zy)
    for i in range(maxit):
      dz=(f(z+complex(h,h))-f(z))/complex(h,h)
      z0=z-f(z)/dz
      if abs(z0-z)<eps: #Tolerancia 
        break
      z=z0
     
      r=i%4*64  
      g=i%8*32
      b=i%16*16
      image.putpixel((x,y),(r,g,b))
image
```




![png](output_7_0.png)



Como podemos observar el codigo que generamos para poder crear este fractal sera la base para poder general los otros tipos de fractales, y en especial, para generar nuevos fractales de Newton lo unico que necesitaremos sera cambiar la función y si deseamos cambiar la escala de colores, como lo veremos en los siguientes ejemplos.


```python
#Newton 1
def f(z): 
  return z**5-z

for y in range(imgy):
  zy=y*(yb-ya)/(imgy-1)+ya
  for x in range(imgx):
    zx=x*(xb-xa)/(imgx-1)+xa
    z=complex(zx,zy)
    for i in range(maxit):
      dz=(f(z+complex(h,h))-f(z))/complex(h,h)
      z0=z-f(z)/dz
      if abs(z0-z)<eps: #Tolerancia 
        break
      z=z0
     
      r=i%16*112  
      g=i%8*25
      b=i%16*4
      image.putpixel((x,y),(r,g,b))
image
```




![png](output_9_0.png)



En este caso podemos ver que la función que genera este fractal es ... y susraices son ....


```python
# Newton 2
def f(z): 
  return z**4-2

for y in range(imgy):
  zy=y*(yb-ya)/(imgy-1)+ya
  for x in range(imgx):
    zx=x*(xb-xa)/(imgx-1)+xa
    z=complex(zx,zy)
    for i in range(maxit):
      dz=(f(z+complex(h,h))-f(z))/complex(h,h)
      z0=z-f(z)/dz
      if abs(z0-z)<eps: #Tolerancia 
        break
      z=z0
     
      r=i%8*32  
      g=i%8*32
      b=i%8*32
      image.putpixel((x,y),(r,g,b))
image
```




![png](output_11_0.png)



En este caso podemos ver que la función que genera este fractal es ... y susraices son ....


```python
#Newton 3
def f(z): 
  return z**7-2*z+5

for y in range(imgy):
  zy=y*(yb-ya)/(imgy-1)+ya
  for x in range(imgx):
    zx=x*(xb-xa)/(imgx-1)+xa
    z=complex(zx,zy)
    for i in range(maxit):
      dz=(f(z+complex(h,h))-f(z))/complex(h,h)
      z0=z-f(z)/dz
      if abs(z0-z)<eps: #Tolerancia 
        break
      z=z0
     
      r=i%4*256  
      g=i%3*256
      b=i%24*256
      image.putpixel((x,y),(r,g,b))
image
```




![png](output_13_0.png)



En este caso podemos ver que la función que genera este fractal es ... y susraices son ....


```python
#Newton 4
def f(z): 
  return z**3-2

for y in range(imgy):
  zy=y*(yb-ya)/(imgy-1)+ya
  for x in range(imgx):
    zx=x*(xb-xa)/(imgx-1)+xa
    z=complex(zx,zy)
    for i in range(maxit):
      dz=(f(z+complex(h,h))-f(z))/complex(h,h)
      z0=z-f(z)/dz
      if abs(z0-z)<eps: #Tolerancia 
        break
      z=z0
     
      r=i%4*60 
      g=i%3*100
      b=i%46*128
      image.putpixel((x,y),(r,g,b))
image
```




![png](output_15_0.png)



En este caso podemos ver que la función que genera este fractal es ... y susraices son ....

# Conjuntos de Julia
Deje que $f ( z )$ una función holomorfa de la esfera de Riemann a sí mismo. Tal $f ( z )$ son precisamente las complejas funciones racionales , es decir, donde $p ( z )$ y $Q ( z )$ son los polinomios complejos . Supongamos que $p$ y $q$ son cada uno no constante y que no tienen raíces comunes. Entonces hay un número finito de conjuntos abiertos $F_1 , ..., F_r $, que se dejan invariante por $f ( z )$ y son tales que: $f (z) = P (z) / q (z)$

Ahora podemos observar un ejemplo que trabajamos en clase


```python
#JULIA ejemplo en clase
def f(z):
    return z**2+complex(0.2,0.3)

for y in range (imgy):
    zy=y*(yb-ya)/(imgy-1)+ya
    for x in range (imgx):
        zx=x*(xb-xa)/(imgx-1)+xa
        z=complex(zx,zy)
        for i in range (maxit):
            z0=f(z)
            if abs(z)>1000:
                break
            z=z0
            r=i*8
            g=i*8
            b=i*8
            image.putpixel((x,y),(r,g,b))
image
```




![png](output_18_0.png)



Al igual que con los fractales Newton al tener un primer codigo podemos genera nuevos fractales de esta familia con el simple hecho de cambiar de función y la tonalidad de colores con la que los representamos  


```python
#Julia 1
def f(z):
    return z**3+complex(0.5,0.8)

for y in range (imgy):
    zy=y*(yb-ya)/(imgy-1)+ya
    for x in range (imgx):
        zx=x*(xb-xa)/(imgx-1)+xa
        z=complex(zx,zy)
        for i in range (maxit):
            z0=f(z)
            if abs(z)>1000:
                break
            z=z0
            r=i*8
            g=i*21
            b=i*64
            image.putpixel((x,y),(r,g,b))
image
```




![png](output_20_0.png)



En este fractal la función que representamos fue ....


```python
#Julia 2
def f(z):
    return z**5+complex(0.2,0.9)

for y in range (imgy):
    zy=y*(yb-ya)/(imgy-1)+ya
    for x in range (imgx):
        zx=x*(xb-xa)/(imgx-1)+xa
        z=complex(zx,zy)
        for i in range (maxit):
            z0=f(z)
            if abs(z)>1000:
                break
            z=z0
            r=i*2
            g=i*8
            b=i*9
            image.putpixel((x,y),(r,g,b))
image
```




![png](output_22_0.png)



En este fractal la función que representamos fue ...


```python
#Julia 3
def f(z):
    return z**6-z**3+z+complex(0.7,0.4)

for y in range (imgy):
    zy=y*(yb-ya)/(imgy-1)+ya
    for x in range (imgx):
        zx=x*(xb-xa)/(imgx-1)+xa
        z=complex(zx,zy)
        for i in range (maxit):
            z0=f(z)
            if abs(z)>1000:
                break
            z=z0
            r=i*47
            g=i*42
            b=i*21
            image.putpixel((x,y),(r,g,b))
image
```




![png](output_24_0.png)



En este fractal la función que representamos fue ...


```python
#Julia 4
def f(z):
    return z**2+complex(0.25,0.56)

for y in range (imgy):
    zy=y*(yb-ya)/(imgy-1)+ya
    for x in range (imgx):
        zx=x*(xb-xa)/(imgx-1)+xa
        z=complex(zx,zy)
        for i in range (maxit):
            z0=f(z)
            if abs(z)>1000:
                break
            z=z0
            r=i*52
            g=i*38
            b=i*12
            image.putpixel((x,y),(r,g,b))
image
```




![png](output_26_0.png)



En este fractal la función que representamos fue

# Sistemas Iterados
Un sistema iterativo de funciones es una construcción matemática usada para representar de manera simple ciertos conjuntos fractales que presenten autosimilaridad. Muchos fractales clásicos autosimilares, autoafines y autoconformes pueden representarse como el único conjunto compacto invariante por un sistema iterativo de funciones contractivas.

Un ejemplo de sistemas iterados es el triangulo de triángulo de sierpinski, para el cual generamos el codigo en clase como se ve ahora


```python
#ejemplo en clase 
fig=plt.figure()
ax=plt.gca()
Tri=np.array([[0,0],[1,0],[0,1],[0,0]])
plt.scatter(Tri.transpose()[0],Tri.transpose()[1])
plt.plot(Tri.transpose()[0],Tri.transpose()[1])
ax.set_xticks(np.arange(-0.2,1.4,0.2))
ax.set_yticks(np.arange(-0.2,1.4,0.2))
plt.grid()
ax.axis("equal")

def transafin(M,t,x):
    y=M@x+t
    return y

transafin([[0.5,0],[0,0.5]],[0,0],Tri[1])

fig=plt.figure()
ax=plt.gca()
Tri=np.array([[0,0],[1,0],[0,1],[0,0]])
tritrans=np.array([transafin([[0.5,0],[0,0.5]],[0,0],i) for i in Tri])
tritrans2=np.array([transafin([[0.5,0],[0,0.5]],[0,0.5],i) for i in Tri])
tritrans3=np.array([transafin([[0.5,0],[0,0.5]],[0.5,0],i) for i in Tri])
plt.scatter(Tri.transpose()[0],Tri.transpose()[1],color='black')
plt.plot(Tri.transpose()[0],Tri.transpose()[1],color='black')
plt.scatter(tritrans.transpose()[0],tritrans.transpose()[1],color='g')
plt.plot(tritrans.transpose()[0],tritrans.transpose()[1],color='g')
plt.scatter(tritrans2.transpose()[0],tritrans2.transpose()[1],color='r')
plt.plot(tritrans2.transpose()[0],tritrans2.transpose()[1],color='r')
plt.scatter(tritrans3.transpose()[0],tritrans3.transpose()[1],color='b')
plt.plot(tritrans3.transpose()[0],tritrans3.transpose()[1],color='b')
ax.set_xticks(np.arange(-0.2,1.4,0.2))
ax.set_yticks(np.arange(-0.2,1.4,0.2))
plt.grid()
ax.axis("equal")


Tri=np.concatenate((tritrans,tritrans2,tritrans3))
Tri

fig=plt.figure()
ax=plt.gca()
Tri=np.array([[0,0]])
for i in range(8):
    tritrans=np.array([transafin([[0.5,0],[0,0.5]],[0,0],i) for i in Tri])
    tritrans2=np.array([transafin([[0.5,0],[0,0.5]],[0,0.5],i) for i in Tri])
    tritrans3=np.array([transafin([[0.5,0],[0,0.5]],[0.5,0],i) for i in Tri])
    Tri=np.concatenate((tritrans,tritrans2,tritrans3))
plt.scatter(Tri.transpose()[0],Tri.transpose()[1],color='black',s=0.2)
ax.set_xticks(np.arange(-0.2,1.4,0.2))
ax.set_yticks(np.arange(-0.2,1.4,0.2))
plt.grid()
ax.axis("equal")
```




    (-0.0505393573850806,
     1.0466331073850808,
     -0.05093588450848501,
     1.0470296345084849)




![png](output_29_1.png)



![png](output_29_2.png)



![png](output_29_3.png)


# Conjuntos de Mandelbrot

El conjunto de Mandelbrot es el conjunto de números complejos para los que la función no divergen cuando iterado de , es decir, para los que la secuencia , , etc., permanece acotada en valor absoluto.$ do{\ Displaystyle f_ {c} (z) = z ^ {2} + c}z = 0{\ Displaystyle f_ {c} (0)}{\ Displaystyle f_ {c} (f_ {c} (0))}$

Ahora observemos un ejemplo que trabajamos en clase 


```python
# Mandelbrot ejemplo en clase 
def f(z,a,b):
    return z**2+complex(a,b)

for y in range (imgy):
    zy=y*(yb-ya)/(imgy-1)+ya
    for x in range (imgx):
        zx=x*(xb-xa)/(imgx-1)+xa
        z=0
        for i in range (maxit):
            z0=f(z,zx ,zy )
            if abs(z)>1000:
                break
            z=z0
            r=i*8
            g=i*8
            b=i*8
            image.putpixel((x,y),(r,g,b))
image
```




![png](output_31_0.png)



Ahora para no extendermos demasiado como con los fractales anteriores, para poder observar los ejemplos que realice de conjuntos de Mandelbrot implemente una herramienta para que su visualizacion sea mas sencilla. 


```python
def Mandelbrot(Ejemplo):
    if Ejemplo=='1':
        try:
          def f(z,a,b):
              return z**2+2*z**3+1+complex(a,b)

          for y in range (imgy):
              zy=y*(yb-ya)/(imgy-1)+ya
              for x in range (imgx):
                  zx=x*(xb-xa)/(imgx-1)+xa
                  z=0
                  for i in range (maxit):
                      z0=f(z,zx ,zy )
                      if abs(z)>1000:
                          break
                      z=z0
                      r=i*25
                      g=i*10
                      b=i*45
                      image.putpixel((x,y),(r,g,b))
          return image
        except:
            pass
    if Ejemplo=='2':
        try:
          def f(z,a,b):
              return z**7-z**3+complex(a,b)

          for y in range (imgy):
              zy=y*(yb-ya)/(imgy-1)+ya
              for x in range (imgx):
                  zx=x*(xb-xa)/(imgx-1)+xa
                  z=0
                  for i in range (maxit):
                      z0=f(z,zx ,zy )
                      if abs(z)>1000:
                          break
                      z=z0
                      r=i*8
                      g=i*14
                      b=i*26
                      image.putpixel((x,y),(r,g,b))
          return image
        
        except:
            pass
    if Ejemplo=='3':
        try:
          def f(z,a,b):
              return z**3+z**2+z+complex(a,b)

          for y in range (imgy):
              zy=y*(yb-ya)/(imgy-1)+ya
              for x in range (imgx):
                  zx=x*(xb-xa)/(imgx-1)+xa
                  z=0
                  for i in range (maxit):
                      z0=f(z,zx ,zy )
                      if abs(z)>1000:
                          break
                      z=z0
                      r=i*10
                      g=i*40
                      b=i*25
                      image.putpixel((x,y),(r,g,b))
          return image
        except:
            pass
    if Ejemplo=='4':
        try:
          def f(z,a,b):
              return z**5-complex(a,b)

          for y in range (imgy):
              zy=y*(yb-ya)/(imgy-1)+ya
              for x in range (imgx):
                  zx=x*(xb-xa)/(imgx-1)+xa
                  z=0
                  for i in range (maxit):
                      z0=f(z,zx ,zy )
                      if abs(z)>1000:
                          break
                      z=z0
                      r=i*45
                      g=i*25
                      b=i*25
                      image.putpixel((x,y),(r,g,b))
          return image
        
        except:
            pass
interact(Mandelbrot, Ejemplo = ['1','2','3', '4'])
```


    interactive(children=(Dropdown(description='Ejemplo', options=('1', '2', '3', '4'), value='1'), Output()), _do…





    <function __main__.Mandelbrot(Ejemplo)>


